<?php 
include('functions/userfunctions.php');
include('includes/header.php'); 
include('includes/slider.php'); 
?>

<div class="py-5">
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <h4>Trending Products</h4>
                <div class="underline mb-2"></div>
                <div class="owl-carousel">
                    <?php
                        $trendingProducts = getAllTrending();

                        if(mysqli_num_rows($trendingProducts)>0)
                        {
                            foreach($trendingProducts as $items)
                            {
                                ?>
                                <div class="item">
                                <a href="product-view.php?product=<?= $items ['slug']; ?>">
                                        <div class="card shadow">
                                            <div class="card-body">
                                                <img src="uploads/<?= $items ['image']; ?>" alt="Product Image" class="w-100">
                                                <h6 class="text-center"><?= $items ['name']; ?></h6>
                                            </div>
                                        </div>
                                    </a>
                                </div>
                            <?php
                            }
                        }
                    ?>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="py-5 bg-f2f2f2">
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <h4>About Us</h4>
                <div class="underline mb-2"></div>
                <p>
                  Devendra Kumar
                </p>
            </div>
        </div>
    </div>
</div>

<div class="py-5 bg-dark">
    <div class="container">
        <div class="row">
            <div class="col-md-3">
                <h4 class="text-white">E-shop</h4>
                <div class="underline mb-2"></div>
                <a href="index.php" class="text-white"><i class="fa fa-angle-right"></i> Home</a><br>
                <a href="#" class="text-white"><i class="fa fa-angle-right"></i> About Us</a><br>
                <a href="cart.php" class="text-white"><i class="fa fa-angle-right"></i> My Cart</a><br>
                <a href="categories.php" class="text-white"><i class="fa fa-angle-right"></i> Our Collections</a><br>
            </div>
            <div class="col-md-3">
                <h4 class="text-white">Address</h4>
                <div class="underline mb-2"></div>
                <p class="text-white">
                    #456, 3rd Floor,<br>
                    Lee road, Men Hostel,<br>
                    VIT, Vellore
                </p>
                <a href="tel:+91 6204277009" class="text-white"><i class="fa fa-phone"></i> +91 6204277009 </a><br>
                <a href="mailto:devendrakumardev@gmail.com" class="text-white"><i class="fa fa-envelope"></i> devendrakumardev@gmail.com</a>
            </div>
            <div class="col-md-6">
            <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3887.9930208332453!2d79.1580941!3d12.972297999999997!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3bad47a10716981f%3A0xee227cf8360c98d7!2sJ%20Block%2C%20VIT%20University%2C%20Vellore%2C%20Tamil%20Nadu%20632014!5e0!3m2!1sen!2sin!4v1691605257722!5m2!1sen!2sin" width="600" height="200" style="border:0;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>
            </div>
        </div>
    </div>
</div>


<?php include('includes/footer.php'); ?>

<script>
    $(document).ready(function(){
        $('.owl-carousel').owlCarousel({
            loop:true,
            margin:10,
            nav:true,
            responsive:{
                0:{
                    items:1
                },
                600:{
                    items:3
                },
                1000:{
                    items:4
                }
            }
        })
    });    
</script>
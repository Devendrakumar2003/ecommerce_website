<?php

include('functions/userfunctions.php');

if(isset($_SESSION['auth']))
{
    unset($_SESSION['auth']);
    unset($_SESSION['auth_user']);
    redirect("index.php","Logged out successfully");
}
?>
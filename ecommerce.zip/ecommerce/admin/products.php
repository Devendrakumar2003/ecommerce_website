<?php

include('includes/header.php');
include('../middleware/adminMiddleware.php');
?>

<div class="container">
    <div class="row">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header bg-primary">
                    <h4 class="text-white">Products</h4>
                </div>
                <div class="card-body">
                    <table class="table table-bordered table-striped">
                        <thead>
                            <tr>
                                <th>ID</th>
                                <th>Name</th>
                                <th>Image</th>
                                <th>Status</th>
                                <th>Edit</th>
                                <th>Delete</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php
                                $products = getAll("products");

                                if(mysqli_num_rows($products)>0)
                                {
                                    foreach($products as $items)
                                    {
                                        ?>
                                            <tr>
                                                <td><?= $items['id']; ?></td>
                                                <td><?= $items['name']; ?></td>
                                                <td>
                                                    <img src="../uploads/<?= $items['image']; ?>" width="100px" height="100px" alt="<?= $items['name']; ?>">
                                                </td>
                                                <td>
                                                    <?= $items['status']=='0' ? "Visible":"Hidden" ?>
                                                </td>
                                                <td>
                                                    <a href="edit-product.php?id=<?= $items['id']; ?>" class="btn btn-sm btn-primary">Edit</a>
                                                </td>
                                                <td>
                                                    <form>
                                                        <input type="hidden" name="product_id" value="<?= $items['id']; ?>">
                                                        <button type="submit" class="btn btn-sm btn-danger" name="delete_product_btn">Delete</button>
                                                    </form>
                                                </td>
                                            </tr>
                                        <?php
                                    }
                                }
                                else
                                {
                                    echo "No records found";
                                }
                            ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>


<?php include('includes/footer.php'); ?>
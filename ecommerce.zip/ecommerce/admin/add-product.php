<?php

include('includes/header.php');
include('../middleware/adminMiddleware.php');
?>

<div class="container">
    <div class="row">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header bg-primary">
                    <h4 class="text-white">Add Product</h4>
                </div>
                <div class="card-body">
                    <form action="code.php" method="POST" enctype="multipart/form-data">
                        <div class="row">
                            <div class="col-md-12">
                                <label class="mb-0">Select Category</label>
                                <select name="category_id" class="form-select mb-2">
                                    <option selected>Select Category</option>
                                    <?php
                                        $categories = getAll("categories");

                                        if(mysqli_num_rows($categories)>0)
                                        {
                                            foreach($categories as $items)
                                            {
                                                ?>
                                                    <option value="<?= $items['id']; ?> "><?= $items['name']; ?></option>
                                                <?php 
                                            }
                                        }
                                        else
                                        {
                                            echo "No category available";
                                        }                                      
                                    ?>                             
                                </select> 
                            </div>
                            <div class="col-md-6">
                                <label class="mb-0">Name</label>
                                <input type="text" name="name" placeholder="Enter product name" class="form-control mb-2">
                            </div>
                            <div class="col-md-6">
                                <label class="mb-0">Slug</label>
                                <input type="text" name="slug" placeholder="Enter slug" class="form-control mb-2">
                            </div>
                            <div class="col-md-6">
                                <label class="mb-0">Original Price</label>
                                <input type="number" name="original_price" placeholder="Enter original price" class="form-control mb-2">
                            </div>
                            <div class="col-md-6">
                                <label class="mb-0">Selling Price</label>
                                <input type="number" name="selling_price" placeholder="Enter selling price" class="form-control mb-2">
                            </div>
                            <div class="col-md-4">
                                <label class="mb-0">Upload Image</label>
                                <input type="file" name="image" class="form-control mb-2">
                            </div>
                            <div class="col-md-4">
                                <label class="mb-0">Display</label>
                                <input type="text" name="display" placeholder="Enter display" class="form-control mb-2">
                            </div>
                            <div class="col-md-4">
                                <label class="mb-0">Processor</label>
                                <input type="text" name="processor" placeholder="Enter processor" class="form-control mb-2">
                            </div>
                            <div class="col-md-4">
                                <label class="mb-0">Front Camera</label>
                                <input type="text" name="front_camera" placeholder="Enter front_camera" class="form-control mb-2">
                            </div>
                            <div class="col-md-4">
                                <label class="mb-0">Rear Camera</label>
                                <input type="text" name="rear_camera" placeholder="Enter rear_camera" class="form-control mb-2">
                            </div>
                            <div class="col-md-4">
                                <label class="mb-0">RAM</label>
                                <input type="text" name="ram" placeholder="Enter ram" class="form-control mb-2">
                            </div>
                            <div class="col-md-4">
                                <label class="mb-0">Storage</label>
                                <input type="text" name="storage" placeholder="Enter slug" class="form-control mb-2">
                            </div>
                            <div class="col-md-4">
                                <label class="mb-0">Battery Capacity</label>
                                <input type="text" name="battery" placeholder="Enter battery" class="form-control mb-2">
                            </div>
                            <div class="col-md-4">
                                <label class="mb-0">OS</label>
                                <input type="text" name="os" placeholder="Enter os" class="form-control mb-2">
                            </div>
                            <div class="row">
                                <div class="col-md-4">
                                    <label class="mb-0">Quantity</label>
                                    <input type="number" name="qty" placeholder="Enter quantity" class="form-control mb-2">
                                </div>
                                <div class="col-md-4">
                                    <label class="mb-0">Status</label><br>
                                    <input type="checkbox" name="status">
                                </div>
                                <div class="col-md-4">
                                    <label class="mb-0">Trending</label><br>
                                    <input type="checkbox" name="popular">
                                </div>
                            </div>                           
                            <div class="col-md-12 mt-2">
                                <button type="submit" name="add_product_btn" class="btn btn-primary">Save</button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>


<?php include('includes/footer.php'); ?> 
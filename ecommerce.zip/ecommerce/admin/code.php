<?php

session_start();
// include('../config/dbcon.php');
// include('../functions/redirect.php');
include('../functions/myfunctions.php');

if(isset($_POST['add_category_btn']))
{
    $name = $_POST['name'];
    $slug = $_POST['slug'];
    $description = $_POST['description'];
    $meta_title = $_POST['meta_title'];
    $meta_description = $_POST['meta_description'];
    $meta_keywords = $_POST['meta_keywords'];
    $status = isset($_POST['status']) ? '1':'0';
    $popular = isset($_POST['popular']) ? '1':'0';

    $image = $_FILES['image']['name'];

    $path = "../uploads";

    $image_ext = pathinfo($image, PATHINFO_EXTENSION);
    $filename = time().'.'.$image_ext;

    $cate_query = "INSERT INTO categories 
    (name,slug,description,meta_title,meta_description,meta_keywords,status,popular,image)
    VALUES ('$name','$slug','$description','$meta_title','$meta_description','$meta_keywords','$status','$popular','$filename')";

    $cate_query_run = mysqli_query($con, $cate_query);

    if($cate_query_run)
    {
        move_uploaded_file($_FILES['image']['tmp_name'], $path.'/'.$filename);
        redirect("add-category.php","Category Added Successfully");
    }
    else
    {
        redirect("add-category.php","Something Went Wrong");
    }
}

else if(isset($_POST['add_product_btn']))
{
    $category_id = $_POST['category_id'];
    $name = $_POST['name'];
    $slug = $_POST['slug'];
    $original_price = $_POST['original_price'];
    $selling_price = $_POST['selling_price'];
    $display = $_POST['display'];
    $processor = $_POST['processor'];
    $front_camera = $_POST['front_camera'];
    $rear_camera = $_POST['rear_camera'];
    $ram = $_POST['ram'];
    $storage = $_POST['storage'];
    $battery = $_POST['battery'];
    $os = $_POST['os'];
    $qty = $_POST['qty'];
    $status = isset($_POST['status']) ? '1':'0';
    $trending = isset($_POST['trending']) ? '1':'0';

    $image = $_FILES['image']['name'];

    $path = "../uploads";

    $image_ext = pathinfo($image, PATHINFO_EXTENSION);
    $filename = time().'.'.$image_ext;

    $product_query = "INSERT INTO products (category_id,name,slug,original_price,selling_price,display,processor,front_camera,
    rear_camera,ram,storage,battery,os,qty,status,trending,image) VALUES ('$category_id','$name','$slug','$original_price',
    '$selling_price','$display','$processor','$front_camera','$rear_camera','$ram','$storage','$battery','$os','$qty',
    '$status','$trending','$filename')";

    $product_query_run = mysqli_query($con, $product_query);

    if($product_query_run)
    {
        move_uploaded_file($_FILES['image']['tmp_name'], $path.'/'.$filename);
        redirect("add-product.php","Product Added Successfully");
    }
    else
    {
        redirect("add-product.php","Something Went Wrong");
    }
}

else if(isset($_POST['update_order_btn']))
{
    $track_no = $_POST['tracking_no'];
    $order_status = $_POST['order_status'];

    $updateOrder_query = "UPDATE orders SET status='$order_status' WHERE tracking_no='$track_no' ";
    $updateOrder_query_run = mysqli_query($con, $updateOrder_query);

    redirect("view-order.php?t=$track_no","Order status updated successfully");
}
?>
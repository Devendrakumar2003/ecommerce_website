<?php 

include('functions/userfunctions.php'); 
include('includes/header.php');

if(isset($_GET['product']))
{
    $product_slug = $_GET['product'];
    $product_data = getSlugActive("products", $product_slug);
    $product = mysqli_fetch_array($product_data);

    if($product)
    {
        ?>
        <div class="py-3 bg-primary">
            <div class="container">
                <h5 class="text-white">
                    <a class="text-white" href="index.php">
                        Home /
                    </a>
                    <a class="text-white" href="categories.php">
                        Brands /
                    </a>  
                    <?= $product['name']; ?>
                </h5>
            </div>
        </div>

        <div class="bg-light py-4">
            <div class="container product_data mt-3">
                <div class="row">
                    <div class="col-sm-4">
                        <div class="shadow">
                            <img src="uploads/<?= $product['image'];?>" alt="Product Image" class="w-100">
                        </div> 
                    </div>
                    <div class="col-md-8">
                        <h4 class="fw-bold"><?= $product['name']; ?></h4>
                        <hr>

                        <div class="row">
                            <div class="col-lg-3">
                                <h4>Rs <span class="text-success fw-bold"><?= $product['selling_price'];?></span></h4>
                            </div>
                            <div class="col-lg-3">
                                <h5>Rs <del class="text-danger"><?= $product['original_price']; ?></del></h5>
                            </div> 
                        </div>

                        <div class="row">
                            <div class="col-md-3">
                                <div class="input-group mb-3" style="width:130px">
                                    <button class="input-group-text decrement-btn">-</button>
                                    <input type="text" class="form-control text-center input-qty bg-white" value="1" disabled>
                                    <button class="input-group-text increment-btn">+</button>
                                </div>
                            </div>
                        </div>
                        
                        <div class="row mt-3">
                            <div class="col-lg-3 mb-1">
                                <button class="btn btn-primary px-4 addToCartBtn" value="<?= $product['id']; ?>"><i class="fa fa-shopping-cart me-2"></i>Add to Cart</button>
                            </div>
                            <div class="col-lg-3">
                                <button class="btn btn-danger px-4"><i class="fa fa-heart me-2"></i>Add to Wishlist</button>
                            </div>
                        </div>

                        <hr>
                        <div class="row">
                            <h5 class="fw-bold mb-3">Key Specs</h5>
                            <div class="col-md-4">
                                <p><i class="fa-solid fa-display"></i> <b>Display</b><br> <?= $product['display'];?></p>
                                <p><i class="fa-solid fa-camera"></i> <b>Rear Camera</b><br> <?= $product['rear_camera'];?></p>
                                <p><i class="fa-solid fa-battery-three-quarters"></i> <b>Battery Capacity</b><br> <?= $product['battery'];?></p>
                            </div>
                            <div class="col-md-4">
                                <p><b><i class="fa-solid fa-microchip"></i> Processor</b><br> <?= $product['processor'];?></p>
                                <p><b><i class="fa-solid fa-memory"></i> RAM</b><br> <?= $product['ram'];?></p>
                                <p><b><i class="fa-solid fa-globe"></i> OS</b><br> <?= $product['os'];?></p>
                            </div>
                            <div class="col-md-4">
                                <p><b><i class="fa-solid fa-camera-rotate"></i> Front Camera</b><br> <?= $product['front_camera'];?></p>
                                <p><b><i class="fa-solid fa-sd-card"></i> Storage</b><br> <?= $product['storage'];?></p>
                            </div>
                        </div>
                        
                        <!-- <i class="fa-solid fa-display"></i>Display: <?= $product['display'];?><br>
                        Processor: <?= $product['processor'];?><br>
                        Front Camera: <?= $product['front_camera'];?><br>
                        Rear Camera: <?= $product['rear_camera'];?><br>
                        RAM: <?= $product['ram'];?><br>
                        Storage: <?= $product['storage'];?><br>
                        Battery Capacity: <?= $product['battery'];?><br>
                        OS: <?= $product['os'];?><br> -->
                    </div>
                </div>
            </div>
        </div>
        
        <?php
    }

    else
    {
        echo "Product not found";
    }

}
else
{
    echo "Something went wrong";
} 
include('includes/footer.php'); ?>
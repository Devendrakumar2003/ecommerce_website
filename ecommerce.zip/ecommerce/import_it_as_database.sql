-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Mar 26, 2024 at 01:25 PM
-- Server version: 10.4.22-MariaDB
-- PHP Version: 8.1.2

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `ecommerce`
--

-- --------------------------------------------------------

--
-- Table structure for table `carts`
--

CREATE TABLE `carts` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `prod_id` int(11) NOT NULL,
  `prod_qty` int(11) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `carts`
--

INSERT INTO `carts` (`id`, `user_id`, `prod_id`, `prod_qty`, `created_at`) VALUES
(14, 2, 3, 1, '2023-08-14 20:29:37');

-- --------------------------------------------------------

--
-- Table structure for table `categories`
--

CREATE TABLE `categories` (
  `id` int(11) NOT NULL,
  `name` varchar(191) NOT NULL,
  `slug` varchar(191) NOT NULL,
  `description` mediumtext DEFAULT NULL,
  `status` tinyint(4) NOT NULL DEFAULT 0,
  `popular` tinyint(4) NOT NULL DEFAULT 0,
  `image` varchar(191) NOT NULL,
  `meta_title` varchar(191) NOT NULL,
  `meta_description` mediumtext NOT NULL,
  `meta_keywords` mediumtext NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `categories`
--

INSERT INTO `categories` (`id`, `name`, `slug`, `description`, `status`, `popular`, `image`, `meta_title`, `meta_description`, `meta_keywords`, `created_at`) VALUES
(1, 'Samsung', 'samsung', 'All kind of mobiles', 0, 1, '1691152433.jpg', 'samsung', 'All kind of mobiles', 'All kind of mobiles            ', '2023-07-07 19:03:06'),
(2, 'OnePlus', 'oneplus', 'mobiles', 0, 1, '1689011688.png', 'OnePlus', 'mobiles', 'mobiles', '2023-07-10 17:54:48'),
(3, 'Realme', 'realme', 'budget smartphone', 0, 0, '1691174317.png', 'realme', 'budget smartphone                                ', 'budget smartphone                                ', '2023-08-04 18:38:37');

-- --------------------------------------------------------

--
-- Table structure for table `orders`
--

CREATE TABLE `orders` (
  `id` int(11) NOT NULL,
  `tracking_no` varchar(191) NOT NULL,
  `user_id` int(191) NOT NULL,
  `name` varchar(191) NOT NULL,
  `phone` bigint(15) NOT NULL,
  `email` varchar(191) NOT NULL,
  `address` mediumtext NOT NULL,
  `pincode` int(191) NOT NULL,
  `total_price` int(191) NOT NULL,
  `payment_mode` varchar(191) NOT NULL,
  `payment_id` varchar(191) DEFAULT NULL,
  `status` tinyint(4) NOT NULL DEFAULT 0,
  `comments` varchar(255) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `orders`
--

INSERT INTO `orders` (`id`, `tracking_no`, `user_id`, `name`, `phone`, `email`, `address`, `pincode`, `total_price`, `payment_mode`, `payment_id`, `status`, `comments`, `created_at`) VALUES
(1, 'ecom4528', 2, 'Shivam', 0, 'shivam@gmail.com', 'vit, vellore', 632014, 87995, 'COD', '', 1, NULL, '2023-08-06 16:21:14'),
(2, 'ecom3093', 2, 'Shivam', 0, 'shivam@gmail.com', 'ahmedabad', 380009, 87995, 'COD', '', 1, NULL, '2023-08-06 16:31:51'),
(3, 'ecom5751', 4, 'Siddharth', 0, 'siddharth@gmail.com', 'vit,vellore', 632014, 383996, 'COD', '', 0, NULL, '2023-08-06 16:50:47'),
(4, 'ecom9953', 4, 'asdf', 0, 'asdf@gmail.com', 'ahmedabad', 380009, 10999, 'COD', '', 0, NULL, '2023-08-06 17:05:29'),
(5, 'ecom3382', 2, 'Shivam', 0, 'shivam@gmail.com', 'ahmedabad', 380009, 49998, 'COD', '', 0, NULL, '2023-08-06 17:41:22');

-- --------------------------------------------------------

--
-- Table structure for table `order_items`
--

CREATE TABLE `order_items` (
  `id` int(11) NOT NULL,
  `order_id` int(191) NOT NULL,
  `prod_id` int(191) NOT NULL,
  `qty` int(191) NOT NULL,
  `price` int(11) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `order_items`
--

INSERT INTO `order_items` (`id`, `order_id`, `prod_id`, `qty`, `price`, `created_at`) VALUES
(1, 1, 3, 3, 17999, '2023-08-06 16:21:14'),
(2, 1, 1, 2, 16999, '2023-08-06 16:21:14'),
(3, 2, 3, 3, 17999, '2023-08-06 16:31:51'),
(4, 2, 1, 2, 16999, '2023-08-06 16:31:51'),
(5, 3, 2, 4, 85000, '2023-08-06 16:50:47'),
(6, 3, 6, 4, 10999, '2023-08-06 16:50:47'),
(7, 4, 6, 1, 10999, '2023-08-06 17:05:29'),
(8, 5, 4, 2, 24999, '2023-08-06 17:41:22');

-- --------------------------------------------------------

--
-- Table structure for table `products`
--

CREATE TABLE `products` (
  `id` int(11) NOT NULL,
  `category_id` int(11) NOT NULL,
  `name` varchar(191) NOT NULL,
  `slug` varchar(191) NOT NULL,
  `original_price` int(11) NOT NULL,
  `selling_price` int(11) NOT NULL,
  `image` varchar(191) NOT NULL,
  `display` varchar(191) NOT NULL,
  `processor` varchar(191) NOT NULL,
  `front_camera` varchar(191) NOT NULL,
  `rear_camera` varchar(191) NOT NULL,
  `ram` varchar(191) NOT NULL,
  `storage` varchar(191) NOT NULL,
  `battery` varchar(191) NOT NULL,
  `os` varchar(191) NOT NULL,
  `qty` int(11) NOT NULL,
  `status` tinyint(4) NOT NULL,
  `trending` tinyint(4) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `products`
--

INSERT INTO `products` (`id`, `category_id`, `name`, `slug`, `original_price`, `selling_price`, `image`, `display`, `processor`, `front_camera`, `rear_camera`, `ram`, `storage`, `battery`, `os`, `qty`, `status`, `trending`, `created_at`) VALUES
(1, 2, 'Nord CE', 'nord ce', 18999, 16999, '1689011915.png', '6.43-inch (1080x2400)', 'Qualcomm Snapdragon 750G', '16MP', '64MP + 8MP + 2MP', '6GB, 8GB, 12GB\n', '128GB, 256GB', '4500mAh', 'Android 11', 50, 0, 1, '2023-07-10 17:58:35'),
(2, 1, 'Galaxy Z Fold5', 'galaxy_z_fold5', 90000, 85000, '1691152433.jpg', '7.60-inch (2176x1812)', 'Snapdragon 8 Gen 2', '10MP + 4MP', '50MP + 12MP + 10MP', '12GB', '256GB, 512GB, 1TB', '4400mAh', 'Android 13', 50, 0, 1, '2023-08-04 12:33:53'),
(3, 2, 'Nord CE 2 Lite', 'nord_ce_2_lite', 19999, 17999, '1691173377.png', '6.59-inch (1080x2412)', 'Qualcomm Snapdragon 695', '16MP', '64MP + 2MP + 2MP', '6GB, 8GB', '128GB', '5000mAh', 'Android 12', 50, 0, 1, '2023-08-04 18:22:57'),
(4, 2, 'Nord CE 3', 'nord_ce_3', 26999, 24999, '1691173518.png', '6.72-inch (1800x2400)', 'Qualcomm Snapdragon 695\n', '16MP', '108MP + 2MP + 2MP', '8GB', '128GB, 256GB', '5000mAh', 'Android 13', 48, 0, 1, '2023-08-04 18:25:18'),
(5, 2, 'Nord 3', 'nord_3', 33999, 31999, '1691173940.png', '6.74-inch (1240x2772)', 'MediaTek Dimensity 9000', 'Unspecified', '50MP + 8MP + 2MP', '8GB, 16GB', '128GB, 256GB', '5000mAh', 'Android', 50, 0, 1, '2023-08-04 18:32:20'),
(6, 3, 'Realme C53', 'realme_c53', 12999, 10999, '1691174434.png', '6.74-inch', 'octa-core', '8MP', '108MP', '4GB, 6GB', '64GB, 128GB', '5000mAh', 'Android 13', 50, 0, 1, '2023-08-04 18:40:34');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `name` varchar(191) NOT NULL,
  `email` varchar(191) NOT NULL,
  `phone` bigint(15) NOT NULL,
  `password` varchar(191) NOT NULL,
  `role_as` tinyint(4) NOT NULL DEFAULT 0,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `email`, `phone`, `password`, `role_as`, `created_at`) VALUES
(1, 'Jay Jain', 'jaydharmawat@gmail.com', 8302115472, '123', 1, '2023-07-04 18:28:34'),
(2, 'Shivam', 'shivam@gmail.com', 5648793215, '1234', 0, '2023-07-05 09:59:36'),
(4, 'siddharth', 'siddharth@gmail.com', 4789652458, '123', 0, '2023-07-05 17:25:11');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `carts`
--
ALTER TABLE `carts`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `categories`
--
ALTER TABLE `categories`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `orders`
--
ALTER TABLE `orders`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `order_items`
--
ALTER TABLE `order_items`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `carts`
--
ALTER TABLE `carts`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT for table `categories`
--
ALTER TABLE `categories`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `orders`
--
ALTER TABLE `orders`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `order_items`
--
ALTER TABLE `order_items`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `products`
--
ALTER TABLE `products`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
